package maze.logic;

import java.io.Serializable;

/**
 * Abstract class that represents the equipment (shield and sword).
 */
public abstract class Equipment extends Item implements Serializable{
	/**
	 * Constructor for class Equipment.
	 * 
	 * @param x x coordinate of the equipment
	 * @param y y coordinate of the equipment
	 */
	public Equipment(int x, int y){
		super(x,y);
	}
	/*public Equipment(int x, int y, GameState g){
		super(x,y, g);
	}*/
}
