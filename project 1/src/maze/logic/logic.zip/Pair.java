package maze.logic;
import java.util.Comparator;

/**
 * 
 */
public class Pair<L extends Comparable<L>, R extends Comparable<R>> {
	public L first;
	public R second;
	
	/**
	 * 
	 */
	public String toString(){
		return first.toString() + " " + second.toString();
	}
	
	/**
	 * 
	 * @param first
	 * @param second
	 */
	public Pair(L first, R second){
		this.first = first;
		this.second= second;
	}
	
	/**
	 * 
	 * @param o
	 */
	public boolean equals(Object o){
		if(! (o instanceof Pair<?,?>) || o == null)
			return false;
		Pair<L,R> p2 = (Pair<L,R>) o;
		return (first.equals(p2.first)) && (second.equals(p2.second));
	}
	
	/**
	 *
	 */
	public class PairPositionComparator implements Comparator<Pair<L,R>>
	{
	    @Override
	    public int compare(Pair<L,R> p1, Pair<L,R> p2)
	    {
	    	if(p1 == null && p2 == null)
	    		return 0;
	    	if(p1 == null)
	    		return -1;
	    	if(p2==null)
	    		return 1;
	    	if(p1.first.compareTo(p2.first) < 0)
	    		return -1;
	    	if(p1.first.compareTo(p2.first) > 0)
	    		return 1;
	    	if(p1.second.compareTo(p2.second) < 0)
	    		return -1;
	    	if(p1.second.compareTo(p2.second) > 0)
	    		return 1;
	    	return 0;
	    }
	}
}




