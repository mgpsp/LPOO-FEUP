package maze.logic;

import java.io.Serializable;

/**
 * Represents the dart quiver.
 */
public class DartQuiver extends Equipment implements Serializable{
	/**
	 * Constructor for class DartQuiver.
	 * 
	 * @param x x coordinate of the dart quiver
	 * @param y y coordinate of the dart quiver
	 * @param numdarts number of darts in the quiver
	 */
	public DartQuiver(int x, int y, int numdarts){
		super(x,y);
		this.numdarts= numdarts;
	}
	/*public DartQuiver(int x, int y, GameState g, int numdarts){
		super(x,y,g);
		this.numdarts= numdarts;
	}*/
	
	/**
	 * Get number of darts in the dart quiver
	 * @return number of darts in the dart quiver
	 */
	public int getNumdarts() {
		return numdarts;
	}
	
	/**
	 * Set number of darts in the dart quiver
	 * @param numdarts
	 */
	public void setNumdarts(int numdarts) {
		this.numdarts = numdarts;
	}
	
	/**
	 * Add darts to the dart quiver
	 * @param numdarts
	 */
	public void addDarts(int numdarts) {
		this.numdarts += numdarts;
	}
	
	/**
	 * 
	 * @return
	 */
	public char getChar(){
		return 'Q';
	}
	
	private int numdarts = 0;
	
	/**
	 * Remove one dart from the dart quiver
	 * @return
	 */
	public boolean decNumDarts(){
		if(numdarts == 0)
			return false;
		numdarts--;
		return true;
	}
}
