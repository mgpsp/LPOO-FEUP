package maze.logic;
/**
 * 
 */
import java.io.Serializable;
import java.util.*;

import maze.logic.Tile;
/**
 * @author up201304000
 *
 */
/**
 *
 */
public class Labyrithm  implements Serializable {
	public static char[][] template1 = 
		{
			{'X','X','X','X','X','X','X','X','X','X'},
			{'X',' ',' ',' ',' ',' ',' ',' ',' ','X'},
			{'X',' ','X','X',' ','X',' ','X',' ','X'},
			{'X',' ','X','X',' ','X',' ','X',' ','X'},
			{'X',' ','X','X',' ','X',' ','X',' ','X'},
			{'X',' ',' ',' ',' ',' ',' ','X',' ','S'},
			{'X',' ','X','X',' ','X',' ','X',' ','X'},
			{'X',' ','X','X',' ','X',' ','X',' ','X'},
			{'X',' ','X','X',' ',' ',' ',' ',' ','X'},
			{'X','X','X','X','X','X','X','X','X','X'},
		};

	private ArrayList<ArrayList<Tile>> maze;
	
	/**
	 * 
	 * @param linsize
	 * @param colsize
	 */
	Labyrithm(int linsize, int colsize){
		maze = new ArrayList<ArrayList<Tile>>();
		for(int i = 0; i < linsize; i++) {
			ArrayList<Tile> temp = new ArrayList<Tile>();
			for(int j = 0; j < linsize; j++)
			{
				temp.add(new Tile());
			}
			maze.add(temp);
		}
	}
	
	/**
	 * 
	 * @param template
	 */
	public Labyrithm(char[][] template)
	{
		this(template.length, template[0].length);
		fill(template);
	}
	
	/**
	 * 
	 * @param template
	 */
	public void fill(char[][] template){
		int lin = template.length;
		int col = template[0].length;
		
		for(int i = 0; i < lin; i++)
			for(int j = 0; j < col; j++)
				setTile(i, j, getTileTypeFromChar(template[i][j]));
	}
	
	/**
	 * 
	 * @return
	 */
	public int getWidth(){
		return maze.get(0).size();
	}
	
	/**
	 * 
	 * @return
	 */
	public int getHeight(){
		return maze.size();
	}
	
	/**
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	public Tile getTile(int x, int y){
		return maze.get(x).get(y);
	}
	
	/**
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	public Tile.TileType getTileType(int x, int y){
		return maze.get(x).get(y).getType();
	}
	
	/**
	 * 
	 * @param p
	 * @return
	 */
	public Tile getPlayerTile(Player p){
		return getTile(p.getX(), p.getY());
	}
	
	/**
	 * 
	 * @param x
	 * @param y
	 * @param newTile
	 * @return
	 */
	public boolean setTile(int x, int y, Tile.TileType newTile){
		if(x < 0 || y < 0 || x >= getWidth() || y >= getHeight())
			return false;
		maze.get(x).get(y).setType(newTile);
		return true;
	}
	
	/**
	 * 
	 * @return
	 */
	public Pair<Integer, Integer> getExitPosition(){
		for(int i = 0; i < getHeight(); i++){
			for(int j = 0; j < getWidth(); j++){
				if(getTileType(i,j).equals(Tile.TileType.EXIT))
					return new Pair<Integer, Integer>(i, j);
			}
		}
		return null;
	}
	/*public char[][] getMatrix(){
		char[][] out = new char[getHeight()][getWidth()];
		for(int i = 0; i < getHeight(); i++){
			for(int j = 0; j < getWidth(); j++){
				out[i][j] = maze.get(i).get(j).getChar();
			}
		}
		return out;
	}*/
	
	/**
	 * 
	 * @param tile
	 * @return
	 */
	public static char getCharFromTileType(Tile.TileType tile){
		if(tile.equals(Tile.TileType.FLOOR))
			return '\0';
		if(tile.equals(Tile.TileType.WALL))
			return 'X';
		if(tile.equals(Tile.TileType.EXIT))
			return 'S';
		else return '\0';
	}
	
	/**
	 * 
	 * @param c
	 * @return
	 */
	public static Tile.TileType getTileTypeFromChar(char c){
		if(c == '\0' || c == ' ')
			return Tile.TileType.FLOOR;
		if(c == 'X')
			return Tile.TileType.WALL;
		if(c == 'S')
			return Tile.TileType.EXIT;
		else return Tile.TileType.FLOOR;
	}
}
