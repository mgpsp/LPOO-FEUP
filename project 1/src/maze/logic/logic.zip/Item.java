package maze.logic;

import java.io.Serializable;

/**
 *
 */
public abstract class Item extends Entity implements Serializable{
	/**
	 * 
	 * @param x
	 * @param y
	 */
	public Item(int x, int y){
		super(x,y);
	}
	/*public Item(int x, int y, GameState g){
		super(x,y, g);
	}*/
}
