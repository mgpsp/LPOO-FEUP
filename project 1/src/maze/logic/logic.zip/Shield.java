package maze.logic;

import java.io.Serializable;

/**
 *
 */
public class Shield extends Equipment implements Serializable{
	/**
	 * 
	 * @param x
	 * @param y
	 */
	public Shield(int x, int y){
		super(x,y);
	}
	/*public Shield(int x, int y, GameState g){
		super(x,y,g);
	}*/
	
	/**
	 * 
	 * @return
	 */
	public char getChar(){
		return 'O';
	}
}
