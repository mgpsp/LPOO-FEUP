package maze.logic;

import java.io.Serializable;

/**
 *
 */
public abstract class Projectile extends Entity  implements Serializable{
	/**
	 * 
	 * @param x
	 * @param y
	 * @param horizontal_movement
	 * @param positive_movement
	 */
	public Projectile(int x, int y, boolean horizontal_movement,boolean positive_movement){
		super(x,y);
		this.horizontal_movement=horizontal_movement;
		this.positive_movement=positive_movement;
	}
	
	/**
	 * 
	 * @param xsource
	 * @param ysource
	 * @param targetx
	 * @param targety
	 */
	public Projectile(int xsource, int ysource, int targetx,int targety){
		super(xsource,ysource);
		int dirx= targetx - xsource;
		int diry = targety - ysource;
		if(dirx != 0 && diry != 0)
			throw new IllegalArgumentException();
		boolean hor, pos;
		if(dirx != 0){
			if(dirx > 0){
				setX(xsource+1);
				this.horizontal_movement=true;
				this.positive_movement=true;
			}
			else{
				setX(xsource-1);
				this.horizontal_movement=true;
				this.positive_movement=false;
			}	
		}
		else{
			if(diry > 0){
				setY(ysource+1);
				this.horizontal_movement=false;
				this.positive_movement=true;
			}
			else{
				setY(ysource-1);
				this.horizontal_movement=false;
				this.positive_movement=false;
			}	
		}
		resetPrevious();
	}
	/*public Projectile(int x, int y, GameState g, boolean horizontal_movement,boolean positive_movement){
		super(x,y,g);
		this.horizontal_movement=horizontal_movement;
		this.positive_movement=positive_movement;
	}*/
	private boolean horizontal_movement;
	private boolean positive_movement;
	private int current_frame=0;
	
	/**
	 * 
	 * @return
	 */
	public int getCurrent_frame() {
		return current_frame;
	}
	
	/**
	 * 
	 * @param current_frame
	 */
	public void setCurrent_frame(int current_frame) {
		this.current_frame = current_frame;
	}
	
	/**
	 * 
	 * 
	 */
	public void incCurrentFrame(){
		this.current_frame++;
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean getHorizontal_movement() {
		return horizontal_movement;
	}
	
	/**
	 * 
	 * @param horizontal_movement
	 */
	public void setHorizontal_movement(boolean horizontal_movement) {
		this.horizontal_movement = horizontal_movement;
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean getPositive_movement() {
		return positive_movement;
	}
	
	/**
	 * 
	 * @param positive_movement
	 */
	public void setPositive_movement(boolean positive_movement) {
		this.positive_movement = positive_movement;
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean move(){
		if(horizontal_movement){
			if(positive_movement)
				setX(getX()+1);
			else
				setX(getX()-1);
		}
		else {
			if(positive_movement)
				setY(getY()+1);
				else
					setY(getY()-1);
		}
		return true;
	}
	
	/**
	 * 
	 * @param g
	 * @return
	 */
	public abstract boolean collision(GameState g);
	
	/**
	 * 
	 * @param e
	 * @return
	 */
	public boolean projectileCollisionCheck(Entity e){
		return e.getDraw() && (getX() == e.getX() && getY() == e.getY()) ||((getPreviousx() == e.getX() && getPreviousy() == e.getY()) && (e.getPreviousx() == getX() && e.getPreviousy() == getY()));
	}
}
