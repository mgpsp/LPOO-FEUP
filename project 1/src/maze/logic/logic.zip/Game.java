package maze.logic;

import java.io.IOException;

import maze.cli.*;
import maze.gui.MazeWindow;

/**
 *
 */
public class Game {
	/**
	 * 
	 * @param args
	 * @throws IOException 
	 */
	/*public static void main(String[] args) {   
 		
		GameState g = Cli.setup();
		while(!GameLogic.winCondition(g))
		{
			Cli.printGame(g);
			GameLogic.Movement input = Cli.input(g);
			if(GameLogic.gameLoop(g, input))
				break;
		}
		Cli.printGame(g);
		Cli.printEnd(GameLogic.winCondition(g));
		Cli.closeInput();
	}*/
	
	/**
	 * 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		//MazeWindow window = new MazeWindow(new GameState(15,3));
		MazeWindow window = MazeWindow.getInstance();
	}
}
