package maze.logic;

import java.util.*;
import java.io.Serializable;
import maze.logic.Dragon.DragonBehaviour;


/**
 *
 */
public class GameState implements Serializable{
	
	private static final int MIN_SIZE = 7;
	private ArrayList<Dragon> dragons= new ArrayList<Dragon>();
	private ArrayList<Item> items = new ArrayList<Item>();
	private  Labyrithm labyrithm = null;
	private  Player player;
	private ArrayList<Projectile> projectiles = new ArrayList<Projectile>();
	private GameSettings settings;
	
	/**
	 * 
	 * @param g2
	 */
	public void copy(GameState g2){
		dragons = g2.dragons;
		items = g2.items;
		labyrithm = g2.labyrithm;
		player = g2.player;
		projectiles = g2.projectiles;
		settings = g2.settings;
	}
	
	/**
	 * 
	 */
	public GameState(){
	}
	
	/**
	 * 
	 * @param size
	 */
	public GameState(int size){
		if(size < MIN_SIZE)
			throw new IllegalArgumentException("illegal maze size");
		MazeGen.genEmpty(this,size);
	}
	
	/**
	 * 
	 * @param size
	 * @param numdragons
	 */
	public GameState(int size, int numdragons){
		if(size < MIN_SIZE)
			throw new IllegalArgumentException("illegal maze size");
		settings = new GameSettings(numdragons, numdragons, size, size, DragonBehaviour.SLEEPING);
		MazeGen.gen(this);
	}
	
	/**
	 * 
	 */
	public void regen(){
		if(settings == null)
			settings = new GameSettings();
		MazeGen.gen(this);
	}
	
	/**
	 * 
	 * @param settings
	 */
	public GameState(GameSettings settings){
		this.settings = settings;	
		MazeGen.gen(this);
	}
	
	/**
	 * 
	 */
	public void restoreSettings(){
		this.settings = new GameSettings(dragons.size(), getNumQuivers(), labyrithm.getHeight(), labyrithm.getWidth(), Dragon.getBehaviour());
	}
	
	/**
	 * 
	 * @param d
	 */
	public void addDragon(Dragon d){
		dragons.add(d);
	}
	
	/**
	 * 
	 * @param item
	 */
	public void addItem(Item item) {
		items.add(item);
	}
	
	/**
	 * 
	 * @param e
	 */
	public void addTileEntity(Entity e){
		labyrithm.getTile(e.getX(), e.getY()).addEntity(e);
	}
	
	/**
	 * 
	 * @return
	 */
	public ArrayList<Dragon> getDragons(){
		return dragons;
	}
	
	/**
	 * 
	 * @return
	 */
	public ArrayList<Item> getItems() {
		return items;
	}
	
	/**
	 * 
	 * @return
	 */
	public Labyrithm getLabyrithm() {
		return labyrithm;
	}
	
	/**
	 * 
	 * @return
	 */
	public Player getPlayer() {
		return player;
	}
	
	/**
	 * 
	 * @return
	 */
	public ArrayList<Projectile> getProjectiles() {
		return projectiles;
	}
	
	/**
	 * 
	 * @param e
	 * @return
	 */
	public boolean removeTileEntity(Entity e){
		return labyrithm.getTile(e.getX(), e.getY()).removeEntity(e);
	}
	
	/**
	 * 
	 * @param labyrithm
	 */
	public void setLabyrithm(Labyrithm labyrithm) {
		this.labyrithm = labyrithm;
	}
	
	/**
	 * 
	 * @param player
	 */
	public void setPlayer(Player player) {
		this.player = player;
	}
	
	/**
	 * 
	 * @param projectile
	 */
	public void addProjectiles(Projectile projectile) {
		projectiles.add(projectile);
	}
	
	/**
	 * 
	 * @param projectile
	 * @return
	 */
	public boolean removeProjectile(Projectile projectile){
		return projectiles.remove(projectile);
	}

	/**
	 * 
	 * @return
	 */
	public int getLiveDragons() {
		int count = 0;
		for(Dragon i : dragons){
			if(i.getDraw())
				count++;
		}
		return count;
	}
	
	/**
	 * 
	 * @return
	 */
	public Pair<Integer, Integer> getHeroPosition() {
		if(player == null)
			return null;
		return new Pair<Integer, Integer>(player.getX(), player.getY());
	}
	
	/**
	 * 
	 * @return
	 */
	public Pair<Integer, Integer> getDragonPosition() {
		if(dragons.size() == 0 || dragons.get(0) == null)
			return null;
		return new Pair<Integer, Integer>(dragons.get(0).getX(), dragons.get(0).getY());
	}
	
	/**
	 * 
	 * @return
	 */
	public Pair<Integer, Integer> getSpadePosition() {
		for(Item i : items){
			if(i  != null && i instanceof Sword){
				return new Pair<Integer, Integer>(i.getX(), i.getY());
			}
		}
		return null;
	}
	
	/**
	 * 
	 * @param arrayList
	 */
	public void setDragons(ArrayList<Dragon> arrayList) {
		dragons = arrayList;
		
	}
	
	/**
	 * 
	 * @param arrayList
	 */
	public void setItems(ArrayList<Item> arrayList) {
		items = arrayList;
		
	}
	
	/**
	 * 
	 * @param arrayList
	 */
	public void setProjectiles(ArrayList<Projectile> arrayList) {
		projectiles = arrayList;
	}
	
	/**
	 * 
	 * @return
	 */
	public GameSettings getSettings(){
		return settings;
	}
	
	/**
	 * 
	 * @return
	 */
	public int getNumQuivers(){
		int count = 0;
		for(Item i  : items )
			if(i instanceof DartQuiver)
				count++;
		return count;
	}
	
	/**
	 * 
	 * @return
	 */
	public ArrayList<Entity> getAllEntities(){
		ArrayList<Entity> out = new ArrayList<Entity>();
		out.add(player);
		out.addAll(dragons);
		out.addAll(items);
		out.addAll(projectiles);
		return out;
	}
	
	/**
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	public Entity tileOccupied(int x, int y) {
		if(labyrithm.getTileType(x,y) != Tile.TileType.FLOOR)
			return null;
		for(Entity e  : getAllEntities()){
			if(e != null && (e.getX() == x && e.getY() == y))
				return e;
		}
		return null;
	}
	
	/**
	 * 
	 * @param d
	 */
	public void removeDragon(Dragon d){
		dragons.remove(d);
	}
	
	/**
	 * 
	 * @param d
	 */
	public void removeItem(Item d){
		items.remove(d);
	}

	public void setSettings(GameSettings gameSettings) {
		this.settings = gameSettings;
	}

}
