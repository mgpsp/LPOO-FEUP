package maze.logic;

import java.io.Serializable;
import java.util.*;

/**
 *
 */
public class Tile  implements Serializable{
	public enum TileType{
		FLOOR, WALL, EXIT,
	}
	private TileType type;
	private LinkedList<Entity> entities = new LinkedList<Entity>();
	
	/**
	 * 
	 * @param type
	 */
	public Tile(TileType type){
		this.type = type;
	}
	
	/**
	 * 
	 */
	public Tile(){
		this(TileType.FLOOR);
	}
	
	/**
	 * 
	 * @return
	 */
	public TileType getType() {
		return type;
	}

	/**
	 * 
	 * @param type
	 */
	public void setType(TileType type) {
		this.type = type;
	}

	/**
	 * 
	 * @return
	 */
	public LinkedList<Entity> getEntities() {
		return entities;
	}

	/**
	 * 
	 * @param newEntity
	 */
	public void addEntity(Entity newEntity) {
		entities.add(newEntity);
	}
	
	/**
	 * 
	 * @param entity
	 * @return
	 */
	public boolean removeEntity(Entity entity) {
		return entities.remove(entity);
	}
	/*public char getChar(){
		if(entities.isEmpty())
			return getCharFromTileType(type);
		//return entities.getLast().getChar();
	}*/
	/*public static char getCharFromTileType(TileType tile){
		if(tile.equals(TileType.FLOOR))
			return '\0';
		if(tile.equals(TileType.WALL))
			return 'X';
		if(tile.equals(TileType.EXIT))
			return 'S';
		else return '\0';
	}
	
	public static TileType getTileTypeFromChar(char c){
		if(c == '\0' || c == ' ')
			return TileType.FLOOR;
		if(c == 'X')
			return TileType.WALL;
		if(c == 'S')
			return TileType.EXIT;
		else return TileType.FLOOR;
	}*/
}
