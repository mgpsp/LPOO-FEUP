package maze.logic;

import java.io.Serializable;

/**
 *
 */
public class Sword extends Equipment  implements Serializable{
	/**
	 * 
	 * @param x
	 * @param y
	 */
	public Sword(int x, int y){
		super(x,y);
	}
	/*public Sword(int x, int y, GameState g){
		super(x,y,g);
	}*/
	/**
	 * 
	 * @return
	 */
	public char getChar(){
		return 'E';
	}
}
