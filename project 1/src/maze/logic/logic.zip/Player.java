package maze.logic;

import java.io.Serializable;
import java.util.*;

/**
 * 
 */
public class Player extends Entity implements Serializable{

	private ArrayList<Equipment> equipped = new ArrayList<Equipment>();
	
	/**
	 * 
	 * @return
	 */
	public ArrayList<Equipment> getEquipped() {
		return equipped;
	}

	/**
	 * 
	 * @param x
	 * @param y
	 */
	public Player(int x, int y){
		super(x,y);
	}
	/*public Player(int x, int y, GameState g){
		super(x,y,g);
	}*/
	/**
	 * 
	 * @return
	 */
	public char getChar(){
		if(!getDraw())
			return 'M';
		if(isArmed())
			return 'A';
		else return 'H';
	}
	
	/**
	 * 
	 * @param i
	 */
	public void takeItem(Item i){
		if(!i.getDraw())
			return;
		i.setDraw(false);
		if(i instanceof Equipment){
			if(i instanceof DartQuiver){
				DartQuiver d = getDartQuiver();
				if(d != null){
					d.addDarts(((DartQuiver)i).getNumdarts());
					return;
				}
			}
		}
		equipped.add((Equipment)i);
	}
	
	/**
	 * 
	 * @return
	 */
	public DartQuiver getDartQuiver(){
		for(Equipment it: equipped){
			if(it instanceof DartQuiver)
				return (DartQuiver)it;
		}
		return null;
	}
	
	/**
	 * 
	 * @return
	 */
	public int getNumDarts(){
		DartQuiver d = getDartQuiver();
		if(d==null)
			return 0;
		return d.getNumdarts();
	}
	
	/**
	 * 
	 * @param x
	 * @param y
	 * @param g
	 * @return
	 */
	public boolean move(int x, int y, GameState g)	{
		Labyrithm l = g.getLabyrithm();
		int newx = getX() + x;
		int newy = getY() + y;
		if(newx < 0 || newy < 0 || newx >= l.getWidth() || newy >= l.getHeight())
			return false;
		if(l.getTileType(newx, newy).equals(Tile.TileType.WALL))
			return false;
		if(l.getTileType(newx, newy).equals(Tile.TileType.EXIT) && (!isArmed()|| g.getLiveDragons() != 0))
			return false;
		
		setXY(newx, newy);

		
		for(Item it : g.getItems())
		{
			if(it.getDraw() && it.getX() == getX() && it.getY() == getY()){
				takeItem(it);
			}
		}
		return true;
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean isArmed(){
		for(Equipment i : equipped){
			if(i instanceof Sword)
				return true;
		}
		return false;
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean isShielded(){
		for(Equipment i : equipped){
			if(i instanceof Shield)
				return true;
		}
		return false;
	}
	
	/**
	 * 
	 * @param p
	 * @return
	 */
	public boolean projectileHit(Projectile p){
		if(p != null && ! (p instanceof Dart) && !isShielded()){
			setDraw(false);
			return true;
		}
		else 
			return false;
	}
	
	/**
	 * 
	 * @param x
	 * @param y
	 * @param g
	 * @return
	 */
	public boolean throwDart(int x, int y, GameState g){
		if(x == 0 && y == 0)
			throw new IllegalArgumentException();
		DartQuiver d;
		if((d=getDartQuiver()) == null)
			return false;
		g.addProjectiles(new Dart(getX()+x, getY()+y, x!=0, (x>0)||(y>0)));
		d.decNumDarts();
		if(d.getNumdarts() == 0)
			equipped.remove(d);
		return true;
	}
}
